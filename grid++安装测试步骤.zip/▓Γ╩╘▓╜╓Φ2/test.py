# coding: gbk

from django.http import HttpResponseRedirect, HttpResponse
from djangoext.mako import render_to_response , render_to_string,render_string
from shangjie.conf import settings
from djangoext.urls import expose
import os,math
from oa.tyhs import print_
@expose( r'^test/$' , preurl = 'mytable/' )
def test( req ):
    
    return render_to_response( 'sj_uni_manage/tmpl/simple.html',profile = req.session['profile'] )
    
@expose( r'^test/dy/$' , preurl = 'mytable/' )
def test( req ):
    try:
        profile = req.session.get('profile' , '1')
        data_lst =  [['20130510','42270','','','20140808','5435','432',
    '\xd2\xbc\xcd\xf2\xb7\xa1\xc7\xaa\xc8\xfe\xb0\xdb\xcb\xc1\xca\xb0\xb0\xc6\xd4\xaa\xcb\xc1\xbd\xc7\xb0\xc6\xb7\xd6', '7209600121200815', '3702980222', '\xc9\xfa\xd3\xfd\xb1\xa3\xcf\xd5\xb7\xd1', '2013-05', '2013-05', '2', '37.40', '0.00', '0.24', '0.00', '37.64', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''], ['20130510', '422709127915917401', '', '\xcb\xbd\xd3\xaa\xc6\xf3\xd2\xb5', '20130510', 'admin', '6022.89', '\xc2\xbd\xc7\xaa\xc1\xe3\xb7\xa1\xca\xb0\xb7\xa1\xd4\xaa\xb0\xc6\xbd\xc7\xbe\xc1\xb7\xd6', '7209600121200815', '3702980222', '\xb9\xa4\xc9\xcb\xb1\xa3\xcf\xd5\xb7\xd1', '2013-05', '2013-05', '2', '44.88', '0.00', '0.29', '0.00', '45.17', '\xbb\xf9\xb1\xbe\xd2\xbd\xc1\xc6\xb1\xa3\xcf\xd5\xb7\xd1', '2013-04', '2013-04', '5', '1151.46', '255.88', '6.31', '0.00', '1413.65', '\xbb\xf9\xb1\xbe\xd1\xf8\xc0\xcf\xb1\xa3\xcf\xd5\xb7\xd1', '2013-04', '2013-04', '5', '2302.92', '1023.52', '14.96', '0.00', '3341.40', '\xca\xa7\xd2\xb5\xb1\xa3\xcf\xd5\xb7\xd1', '2013-04', '2013-04', '5', '255.88', '127.94', '1.71', '0.00', '385.53', '\xb9\xa4\xc9\xcb\xb1\xa3\xcf\xd5\xb7\xd1', '2013-04', '2013-04', '5', '89.51', '0.00', '0.41', '0.00', '89.92', '\xc9\xfa\xd3\xfd\xb1\xa3\xcf\xd5\xb7\xd1', '2013-04', '2013-04', '5', '127.94', '0.00', '0.57', '0.00', '128.51', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''], ['20130510', '422709127909054601', '', '', '20130510', 'admin', '4858.05', '\xcb\xc1\xc7\xaa\xb0\xc6\xb0\xdb\xce\xe9\xca\xb0\xb0\xc6\xd4\xaa\xc1\xe3\xce\xe9\xb7\xd6', '7209600121200815', '3702980297', '\xbb\xf9\xb1\xbe\xd1\xf8\xc0\xcf\xb1\xa3\xcf\xd5\xb7\xd1', '2013-05', '2013-05', '3', '1080.00', '480.00', '10.14', '0.00', '1570.14', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''], ['20130510', '422709127997353301', '', '', '20130510', 'admin', '221.66', '\xb7\xa1\xb0\xdb\xb7\xa1\xca\xb0\xd2\xbc\xd4\xaa\xc2\xbd\xbd\xc7\xc2\xbd\xb7\xd6', '7209600121200815', '3729940339', '\xb9\xa4\xc9\xcb\xb1\xa3\xcf\xd5\xb7\xd1', '2013-06', '2013-06', '4', '52.36', '0.00', '0.00', '0.00', '52.36', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '']
        ]
        xmlfname = print_( {'data_lst':data_lst },'C02_qdck_sbpzdy_pdf.xml',filename = 'GRFXML.XML' )
        
        grffname = print_( {},'C02_qdck_sbpzdy_pdf.grf',filename = 'GRFXML.grf' )
        return HttpResponse( sjapi.jsondumps( grffname + "," +xmlfname , ensure_ascii = False , encoding = 'gbk' ) )
    except:
        raise
        return HttpResponse( sjapi.jsondumps( '0' , ensure_ascii = False , encoding = 'gbk' ) )
    #return render_to_response( 'sj_uni_manage/tmpl/simple.htm',profile = profile,xmlfname = 'GRFXML.XML',grffname = 'GRFXML.grf' )